# Practica 2

- Cambio escena con 1 y 2

- Cambio sombreado con n y m para la escena 2 

-  hacer un make total para tanto borrar como ejecutar la practica, tambien tienes un make clean y un make ejecutar para hacerlo diferente




